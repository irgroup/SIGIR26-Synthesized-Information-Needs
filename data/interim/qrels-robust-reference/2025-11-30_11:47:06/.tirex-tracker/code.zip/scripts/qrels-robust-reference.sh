# Generate qrels based on the original robust topics

# MODEL=qwen3-30B-MT100-no-think
# MODEL=qwen3-14B-MT100-no-think
MODEL=gpt-oss-120B-MT1000
MODEL=70B_instruct_q8_0_MT1000_ollama
# MODEL=gpt-oss-20B
DATASET=robust
# CONNECTION=http://localhost:6543/v1
CONNECTION=http://localhost:11411


# Original Topics
PROMPT=-DNA-zero-shot
OUTPUT=../data/interim/qrels-robust-reference
python ./gen-qrels.py \
    --model $MODEL \
    --data $DATASET \
    --connection $CONNECTION \
    --prompt $PROMPT \
    --output $OUTPUT 
