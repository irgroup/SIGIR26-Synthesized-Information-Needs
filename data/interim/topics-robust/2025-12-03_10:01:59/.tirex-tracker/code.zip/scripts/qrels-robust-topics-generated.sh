#!/bin/bash
# MODEL=qwen3-30B-MT100-no-think
MODEL=gpt-oss-120B-MT1000
DATASET=robust
CONNECTION=http://localhost:6543/v1
MAX_CONCURRENCY=10

# Generated Topics
TOPICS_DIR="/workspaces/conf26-generating-topics/data/interim/topics-robust"
for dir in "$TOPICS_DIR"/*; do
    if [ -d "$dir" ]; then
        python ./gen-qrels.py \
            --model $MODEL \
            --max_concurrency $MAX_CONCURRENCY \
            --data $DATASET \
            --connection $CONNECTION \
            --prompt -DNA-zero-shot \
            --topics "$dir" \
            --output /workspaces/conf26-generating-topics/data/interim/qrels-robust-topics-generated
    fi
done
