#!/bin/bash
MODEL=qwen3-30B-no-think
MAX_CONCURRENCY=6

# MODEL=qwen3-80B-next-no-think

# MODEL=gpt-oss-20B

# MODEL=gpt-oss-120B

# MODEL=llama3-3-70b_instruct_q8
# MAX_CONCURRENCY=6

CONNECTION=http://localhost:6543/v1

DATASET=robust

# Generated Topics
TOPICS_DIR="/workspaces/conf26-generating-topics/data/interim/robust/topics/Qwen3-Next-80B"
for dir in "$TOPICS_DIR"/*; do
    if [ -d "$dir" ]; then
        python ./gen-qrels.py \
            --model $MODEL \
            --max_concurrency $MAX_CONCURRENCY \
            --data $DATASET \
            --connection $CONNECTION \
            --prompt -DNA-zero-shot \
            --topics "$dir" \
            --output /workspaces/conf26-generating-topics/data/interim/qrels-topics-generated
    fi
done
