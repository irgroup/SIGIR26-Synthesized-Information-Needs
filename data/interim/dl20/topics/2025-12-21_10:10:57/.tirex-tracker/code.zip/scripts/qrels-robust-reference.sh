# Generate qrels based on the original robust topics

# MODEL=qwen3-30B-MT100-no-think
# MODEL=qwen3-14B-MT100-no-think
# MODEL=gpt-oss-120B-MT1000
# MODEL=llama3-1-70B_instruct_q8_0_MT1000_ollama
# MODEL=gpt-oss-20B
# MODEL=qwen3-80B-next-no-think
# MODEL=llama3-3-70b_instruct_q8
MODEL=gpt-oss-120B
DATASET=robust
# CONNECTION=http://localhost:6543/v1
# CONNECTION=http://localhost:11411
CONNECTION=http://139.6.160.34:6543/v1


# Original Topics
PROMPT=-DNA-zero-shot
# OUTPUT=../data/interim/robust/qrels-reference
OUTPUT=.
python ./gen-qrels.py \
    --model $MODEL \
    --data $DATASET \
    --connection $CONNECTION \
    --prompt $PROMPT \
    --output $OUTPUT \
    --max_concurrency 17
